package model.carrello;

import model.storage.ConPool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;

public class CarrelloDAO implements CarrelloDAOMethod {

    @Override
    public Optional<Carrello> cercaCarrello(int codiceCarrello){
        try (Connection connection = ConPool.getConnection()) {
            PreparedStatement ps;
            ps = connection.prepareStatement("select * from Carrello where codiceCarrello=? ");
            ps.setInt(1, codiceCarrello);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Carrello carrello = new Carrello();
                carrello.setCodiceCarrello(rs.getInt(1));
                carrello.getUtente().setCodiceFiscale(rs.getString(2));
                carrello.setTotaleProdotti(rs.getInt(3));
                return Optional.of(carrello);
            }
        } catch (SQLException sqlException) {
            throw new RuntimeException(sqlException);
        }
        return Optional.empty();
    }

    @Override
    public void deleteCarrello(int codiceCarrello) {
        try (Connection connection = ConPool.getConnection()) {
            PreparedStatement ps;
            ps = connection.prepareStatement("delete from Carrello where codiceCarrello=?");
            ps.setInt(1, codiceCarrello);
            ps.execute();
        } catch (SQLException sqlException) {
            throw new RuntimeException(sqlException);
        }
    }

    @Override
    public void insertCarrello(Carrello c){
        try (Connection connection = ConPool.getConnection()) {
            PreparedStatement ps = connection.prepareStatement("insert into Carrello value (?,?,?)");
            ps.setInt(1, c.getCodiceCarrello());
            ps.setString(2, c.getUtente().getCodiceFiscale());
            ps.setInt(3, c.getTotaleProdotti());
            ps.execute();
        } catch (SQLException sqlException) {
            throw new RuntimeException(sqlException);
        }
    }

    @Override
    public void updateCarrello(Carrello c, int codiceCarrello){
        // Metodo inutile per 'carrello', siccome sono tutti attributi non modificabili
    }

    @Override
    public ArrayList<Carrello> doRetraiveByAllCarrelli() {
        try (Connection connection = ConPool.getConnection()) {
            PreparedStatement ps;
            ps = connection.prepareStatement("select * from Carrello");
            ResultSet rs = ps.executeQuery();
            ArrayList<Carrello> lista = new ArrayList<>();
            while (rs.next()) {
                Carrello carrello=new Carrello();
                carrello.setCodiceCarrello(rs.getInt(1));
                carrello.getUtente().setCodiceFiscale(rs.getString(2));
                carrello.setTotaleProdotti(rs.getInt(3));
                lista.add(carrello);
            }
            connection.close();
            return lista;
        } catch (SQLException sqlException) {
            throw new RuntimeException(sqlException);
        }
    }

    @Override
    public ArrayList<Carrello> cercaCarrelli(int start, int end) {
        ArrayList<Carrello> lista =new ArrayList<>();
        try(Connection connection=ConPool.getConnection()){

            PreparedStatement ps=connection.prepareStatement("select * from Carrello order by codiceCarrello" +
                    "limit ? offset ?");
            ps.setInt(1,start);
            ps.setInt(2,end);
            ResultSet rs= ps.executeQuery();
            while (rs.next()){
                Carrello carrello=new Carrello();
                carrello.setCodiceCarrello(rs.getInt(1));
                carrello.getUtente().setCodiceFiscale(rs.getString(2));
                carrello.setTotaleProdotti(rs.getInt(3));
                lista.add(carrello);
            }
            connection.close();
            return lista;
        }catch (SQLException sqlException){
            throw new RuntimeException(sqlException);
        }
    }
}